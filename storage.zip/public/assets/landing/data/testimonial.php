<?php

return [
    [
        'image' => asset('public/assets/landing') . "/image/img-1.png",
        'name' => 'Barry Allen',
        'position' => 'Web Designer',
        'detail' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. A
                    aliquam amet animi blanditiis consequatur debitis dicta
                    distinctio, enim error eum iste libero modi nam natus
                    perferendis possimus quasi sint sit tempora voluptatem. Est,
                    exercitationem id ipsa ipsum laboriosam perferendis temporibus!'
    ],
    [
        'image' => asset('public/assets/landing') . "/image/img-2.png",
        'name' => 'Sophia Martino',
        'position' => 'Web Designer',
        'detail' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. A
                    aliquam amet animi blanditiis consequatur debitis dicta
                    distinctio, enim error eum iste libero modi nam natus
                    perferendis possimus quasi sint sit tempora voluptatem. Est,
                    exercitationem id ipsa ipsum laboriosam perferendis temporibus!'
    ],
    [
        'image' => asset('public/assets/landing') . "/image/img-3.png",
        'name' => 'Alan Turing',
        'position' => 'Web Designer',
        'detail' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. A
                    aliquam amet animi blanditiis consequatur debitis dicta
                    distinctio, enim error eum iste libero modi nam natus
                    perferendis possimus quasi sint sit tempora voluptatem. Est,
                    exercitationem id ipsa ipsum laboriosam perferendis temporibus!'
    ],
    [
        'image' => asset('public/assets/landing') . "/image/img-4.png",
        'name' => 'Ann Marie',
        'position' => 'Web Designer',
        'detail' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. A
                    aliquam amet animi blanditiis consequatur debitis dicta
                    distinctio, enim error eum iste libero modi nam natus
                    perferendis possimus quasi sint sit tempora voluptatem. Est,
                    exercitationem id ipsa ipsum laboriosam perferendis temporibus!'
    ],
];
